import { Component } from 'react'

import SettingAccount from './components/settingProfile/account.jsx'

class index extends Component {
  render() {
    return (
      <>
        <SettingAccount />
      </>
    )
  }
}

export default index
