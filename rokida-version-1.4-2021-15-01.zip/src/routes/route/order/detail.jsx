import React from 'react'

// import * as  FontFa from 'react-icons/fa'

import Loader from '../../../components/Rokida/Seller/Loading/spinner.jsx'
import StepProgressBar from 'react-step-progress'
import 'react-step-progress/dist/index.css'

// Import data

class detail extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      loader: false
    }
  }

  componentDidMount() {
  }

  render() {
    return (
      <>
        {this.state.loader === true ? <Loader /> : ''}
        <div className='row p-0 m-0'>
          <div className='pagination col-12 p-0 m-0'>
            <div className="fillter col-12 p-0 m-0">
              <div className="row p-0 m-0">
                {/*  */}
                <div className="container-fluid">
                  <div className="col-12 p-0 m-0">
                    <div className="row p-0 m-0">
                      {/* Status and ID */}
                      <div className="col-12 m-0 p-0 py-2">
                        <div className="row p-0 m-0 justify-content-between">
                          <div className="back">
                            <span className="btn btn-secondary">TRỞ LẠI</span>
                          </div>
                          <div className="id status">
                            <span><span className="text-warning">ID ĐƠN HÀNG. 201111PB48A7DF</span>&nbsp;|&nbsp;Đã giao</span>
                          </div>
                        </div>
                      </div>
                      {/* Shipping */}
                      <div className="col-12 m-0 p-0 py-2">
                        <div className="row p-0 m-0">
                          <div className="col-12 p-0 m-0 py-2">
                            <span className="h4">
                              Trạng thái đơn hàng
                            </span>
                          </div>
                          <div className="col-12 p-0 m-0 py-2">
                            <StepProgressBar
                              startingStep={2}
                              buttonWrapperClass ={'d-none'}
                              steps={[
                                {
                                  label: 'Xác nhân đơn hàng',
                                  // subtitle: '',
                                  // name: '',
                                },
                                {
                                  label: 'Đã xác nhân thông tin thanh toán'
                                },
                                {
                                  label: 'Đã giao cho đơn vị vân chuyển'
                                },
                                {
                                  label: 'Đang giao hàng'
                                },
                                {
                                  label: 'Giao hàng thành công'
                                }
                              ]}
                            />
                          </div>
                          <div className="col-12 m-0 p-3 bg-warning">
                            <span>Đơn hàng này đã hoàn thành.</span>
                          </div>
                        </div>
                      </div>
                      <div className="col-12 m-0 p-0 py-2">
                        <div className="row p-0 m-0">
                          <div className="col-12 p-0 m-0 py-2">
                            <hr className="horizontal-line" />
                          </div>
                        </div>
                      </div>
                      <div className="col-12 m-0 p-0 pb-2">
                        {/* Dia chi nhan hang */}
                        <div className="row p-0 m-0">
                          <div className="col-12 p-2 m-0">
                            <p className='mb-2 h4 font-weight-bold'>Địa chỉ nhận hàng</p>
                            <p className='mb-2 h5'>Nguyễn Minh Phương</p>
                            <p className='mb-2 h6 text-secondary'>(+84) 389902073</p>
                            <p className='mb-2 text-secondary'>Landmark 5, Nguyễn Hữu Cảnh, Vinhomes Tân Cảng, Phường 22, Bình Thạnh, Thành phố Hồ Chí Minh, Phường 22, Quận Bình Thạnh, TP. Hồ Chí Minh</p>
                          </div>
                        </div>
                      </div>
                      <div className="col-12 m-0 p-0 py-2">
                        <div className="row p-0 m-0">
                          <div className="col-12 p-0 m-0 py-2">
                            <hr className="horizontal-line" />
                          </div>
                        </div>
                      </div>
                      <div className="col-12 m-0 p-0 py-2">
                       <div className="row p-0 m-0">
                          <div className="col-12 p-2 m-0">
                            <p className='mb-2 h4 font-weight-bold'>Chi tiết vân chuyển</p>
                            <p className='mb-2 h5'>Standard Express</p>
                            <p className='mb-2 h6 text-secondary'>VN202867207677W</p>
                            <ul className="detail-shipping">
                              <li>Người bán chuẩn bị đơn hàng</li>
                              <li>Bàn giao cho đơn vị vặn chuyển</li>
                              <li className="text-warning">Đã lấy hàng thành công</li>
                              <li>Đang giao hàng </li>
                              <li>Giao kiện thành công | Ký nhận </li>
                            </ul>
                          </div>
                        </div>
                      </div>
                      <div className="col-12 m-0 p-0 py-2">
                        {/*  */}
                      </div>
                      <div className="col-12 m-0 p-0 py-2">
                        {/*  */}
                      </div>
                      <div className="col-12 m-0 p-0 py-2">
                        {/*  */}
                      </div>
                    </div>
                  </div>
                </div>
                {/*  */}
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default detail
