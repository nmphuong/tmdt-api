import React from 'react'

import * as FontFa from 'react-icons/fa'

import ModalAdd from './modalAdd.jsx'
import ModalEdit from './modalEditAddress.jsx'

import { Modal } from 'react-bootstrap'

class contentPage extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      show: false,
      show_1: false,
      show_2: false,
      show_3: false,
      show_4: false,
      show_5: false
    }
  }

  componentDidMount() {
    this.addEvent()
  }

  addEvent = async () => {
    document.getElementById('add-address').addEventListener('click', this.ShowAddModal)
  }

  ShowAddModal = async () => {
    this.setState({
      show: true
    })
    document.getElementById('cancel-add-address').addEventListener('click', this.hideAddModal)
  }

  hideAddModal = async () => {
    this.setState({
      show: false
    })
  }

  ShowEditModal1 = async () => {
    console.log(1)
    await this.setState({
      show_1: true
    })
    document.getElementById('cancel-edit-address_1').addEventListener('click', this.hideEditModal1)
  }

  hideEditModal1 = async () => {
    this.setState({
      show_1: false
    })
  }
  
  render() {
    return (
      <>
        <Modal size="lg" aria-labelledby="contained-modal-title-vcenter" centered show={this.state.show} onHide={this.hideAddModal}>
          <ModalAdd />
        </Modal>
        <div className="row p-0 m-0">
          <div className="col-lg-1"><FontFa.FaMapMarkerAlt /></div>
            <div className="col-lg-9">
              <div className="row p-0 m-0">
                <div className="col-lg-3">
                  <p>Họ	&amp; Tên</p>
                </div>
                <div className="col-lg-9">
                  <p className="font-weight-bold">Nguyễn Minh Phương </p>
                </div>
              </div>
              <div className="row p-0 m-0">
                <div className="col-lg-3">
                  <p>Số điện thoại</p>
                </div>
                <div className="col-lg-9">
                  <p>+84389902073 </p>
                </div>
              </div>
              <div className="row p-0 m-0">
                <div className="col-lg-3">
                  <p>Địa chỉ</p>
                </div>
                <div className="col-lg-9">
                  <p>451 Lê Văn Thọ, Phường 9, Gò Vấp, Thành phố Hồ Chí Minh</p>
                  <p>Phường 9</p>
                  <p>Quận Gò Vấp</p>
                  <p>TP. Hồ Chí Minh</p>
                </div>
              </div>
            </div>
          <div className="col-lg-2">
            <div className="row justify-content-end">
              <div className="col-12 d-flex justify-content-end text-right">
                <button onClick={this.ShowEditModal1} className="btn bg-none text-primary">Sửa</button>
              </div>
              <div className="col-12 d-flex justify-content-end text-right">
                <button className="btn bg-none text-primary">Xóa</button>
              </div>
            </div>
          </div>
        </div>
        <Modal size="lg" aria-labelledby="contained-modal-title-vcenter" centered show={this.state.show_1} onHide={this.hideEditModal1}>
          <ModalEdit />
        </Modal>
        <hr className="my-2" />
        <div className="row p-0 m-0">
          <div className="col-lg-1"><FontFa.FaMapMarkerAlt /></div>
            <div className="col-lg-9">
              <div className="row p-0 m-0">
                <div className="col-lg-3">
                  <p>Họ	&amp; Tên</p>
                </div>
                <div className="col-lg-9">
                  <p className="font-weight-bold">Nguyễn Minh Phương </p>
                </div>
              </div>
              <div className="row p-0 m-0">
                <div className="col-lg-3">
                  <p>Số điện thoại</p>
                </div>
                <div className="col-lg-9">
                  <p>+84389902073 </p>
                </div>
              </div>
              <div className="row p-0 m-0">
                <div className="col-lg-3">
                  <p>Địa chỉ</p>
                </div>
                <div className="col-lg-9">
                  <p>451 Lê Văn Thọ, Phường 9, Gò Vấp, Thành phố Hồ Chí Minh</p>
                  <p>Phường 9</p>
                  <p>Quận Gò Vấp</p>
                  <p>TP. Hồ Chí Minh</p>
                </div>
              </div>
            </div>
          <div className="col-lg-2">
            <div className="row justify-content-end">
              <div className="col-12 d-flex justify-content-end text-right">
                <button className="btn bg-none text-primary">Sửa</button>
              </div>
              <div className="col-12 d-flex justify-content-end text-right">
                <button className="btn bg-none text-primary">Xóa</button>
              </div>
            </div>
          </div>
        </div>
        <Modal size="lg" aria-labelledby="contained-modal-title-vcenter" centered show={this.state.show} onHide={this.hideAddModal}>
          <ModalEdit />
        </Modal>
        <hr className="my-2" />
      </>
    );
  }
}

export default contentPage
