export const dataComponent = {
  link_detail_product: [
    {
      href: "portal/sale/product/detail",
      name: "Chi tiết sản phẩm"
    }
  ]
}