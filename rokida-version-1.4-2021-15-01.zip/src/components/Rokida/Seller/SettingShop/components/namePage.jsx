import { Component } from 'react'

class namePage extends Component {
  render() {
    return (
      <>
        <p className="font-weight-bold h4">
        Thiết Lập Shop 
        </p>
        <p className="text-name text-secondary">
          Thay đổi các cài đặt cho Shop của bạn.
        </p>
      </>
    );
  }
}

export default namePage
