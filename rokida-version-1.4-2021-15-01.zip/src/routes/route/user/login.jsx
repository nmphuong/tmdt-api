// Import Component React
import { Component } from 'react'
// Import Component view
import LoginView from '../../../components/Rokida/Seller/Auth/auth_Login/index.jsx'

class login extends Component {
  render() {
    return (
      <>
        <LoginView />
      </>
    );
  }
}

export default login
