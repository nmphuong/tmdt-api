// import Home from './components/Rokida/Customer/Home/Home';
import Layout from './components/Rokida/Seller/index.jsx'

function App() {
  return (
    <div className="App">
      <Layout />
    </div>
  );
}

export default App;
