// Import Component React
import { Component } from 'react'
// Import Component view
import RegisterView from '../../../components/Rokida/Seller/Auth/auth_Register/index.jsx'

class register extends Component {
  render() {
    return (
      <>
        <RegisterView />
      </>
    );
  }
}

export default register
