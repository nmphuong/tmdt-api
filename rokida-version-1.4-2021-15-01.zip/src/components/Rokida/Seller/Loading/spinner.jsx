import { Component } from 'react'

class spinner extends Component {
  render() {
    return (
      <>
        <div className="loader">
          <div  className="db-spinner"></div>
        </div>
      </>
    );
  }
}

export default spinner
