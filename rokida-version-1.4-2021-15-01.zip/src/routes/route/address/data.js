export const dataComponent = {
  link_setting_address: [
    {
      href: "/portal/settings/shop/address",
      name: "Địa chỉ"
    }
  ]
}