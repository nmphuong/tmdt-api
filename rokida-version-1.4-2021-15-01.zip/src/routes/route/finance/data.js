export const dataComponent = {
  link_setting_bank_account: [
    {
      href: "/portal/sale/finance/wallet/cards",
      name: "Tài khoản ngân hàng"
    }
  ]
}