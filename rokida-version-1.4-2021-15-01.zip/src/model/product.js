export const Product = {
  sku: undefined,
  name: undefined,
  price: undefined,
  thumb: [],
  image: [],
  amount: undefined,
  location: undefined,
  status: 1,
  book: 0,
  hidden: 0
}
