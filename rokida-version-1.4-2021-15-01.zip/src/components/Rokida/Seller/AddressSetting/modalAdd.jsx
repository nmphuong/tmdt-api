import { Component } from 'react'

import { Modal, Button } from 'react-bootstrap'

class modal extends Component {
  render() {
    return (
      <>
        <Modal.Header closeButton>
          <Modal.Title>
            <p className="font-weight-bold m-0">
              Thêm Địa Chỉ Mới
            </p>
          </Modal.Title>
        </Modal.Header>
        <Modal.Body id="body-add-address">
          <div className="row p-0 m-0">
            {/*  */}
            <div className="col-lg-12 px-0 m-0 pt-2 pb-4">
              <p className="mb-1">Họ &amp; Tên</p>
              <input className="form-control" placeholder="Nhập vào" />
            </div>
            {/*  */}
            <div className="col-lg-12 px-0 m-0 pt-2 pb-4">
              <p className="mb-1">Số điện thoại</p>
              <input className="form-control" placeholder="Nhập vào" />
            </div>
            {/*  */}
            <div className="col-lg-12 px-0 m-0 pt-2 pb-4">
              <p className="mb-1">Tỉnh/Thành Phố</p>
              <select name="" id="" className="form-control">
                <option value="">TP.Hồ Chí Minh</option>
              </select>
            </div>
            {/*  */}
            <div className="col-lg-12 px-0 m-0 pt-2 pb-4">
              <p className="mb-1">Quận/Huyện</p>
              <select name="" id="" className="form-control">
                <option value="">Gò Vấp</option>
              </select>
            </div>
            {/*  */}
            <div className="col-lg-12 px-0 m-0 pt-2 pb-4">
              <p className="mb-1">Phường/Xã</p>
              <select name="" id="" className="form-control">
                <option value="">Phường 9</option>
              </select>
            </div>
            {/*  */}
            <div className="col-lg-12 px-0 m-0 pt-2 pb-4">
              <p className="mb-1">Địa chỉ chi tiết</p>
              <textarea name="" id="" className="form-control" rows="5" placeholder="Số nhà, tên đường, v.v.."></textarea>
            </div>
            {/*  */}
            <div className="col-lg-12 px-0 m-0 pt-2 pb-4">
              <div className="row p-0 m-0">
                <div className="col-12 p-0 m-0">
                  <input type="checkbox" className="" />
                  <label className="ml-2" htmlFor="">Đặt làm địa chỉ mặc định</label>
                </div>
                <div className="col-12 p-0 m-0">
                  <input type="checkbox" className="" />
                  <label className="ml-2" htmlFor="">Đặt làm địa chỉ lấy hàng</label>
                </div>
                <div className="col-12 p-0 m-0">
                  <input type="checkbox" className="" />
                  <label className="ml-2" htmlFor="">Đặt làm địa chỉ nhận hàng</label>
                </div>
              </div>
            </div>
            {/*  */}
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button id="cancel-add-address" variant="outline-dark">
            Hủy
        </Button>
          <Button variant="warning">
            Lưu
        </Button>
        </Modal.Footer>
      </>
    );
  }
}

export default modal
