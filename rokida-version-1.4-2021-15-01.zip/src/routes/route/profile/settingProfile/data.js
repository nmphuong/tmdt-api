export const dataComponent = {
  link_setting_account: [
    {
      href: "/portal/settings/account",
      name: "Tài khoản"
    }
  ]
}