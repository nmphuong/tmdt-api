export const dataComponent = {
  link_product_all: [
    {
      href: "/portal/settings/shop/logistics",
      name: "Cài đặt vận chuyển"
    }
  ]
}